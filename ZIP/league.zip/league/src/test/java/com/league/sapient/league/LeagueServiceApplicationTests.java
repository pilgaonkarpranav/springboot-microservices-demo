package com.league.sapient.league;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeagueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
