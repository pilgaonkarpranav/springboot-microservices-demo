package com.league.sapient.Standings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StandingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StandingsApplication.class, args);
	}

}
