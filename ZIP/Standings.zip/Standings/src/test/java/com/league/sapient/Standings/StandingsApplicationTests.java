package com.league.sapient.Standings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
